export const environment = {
  envType: 'prod',
  apiUrl: 'http://77.220.213.35:3030/'
};