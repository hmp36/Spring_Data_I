export const environment = {
  envType: 'localServer',
  apiUrl: 'http://localhost:3030/'
};