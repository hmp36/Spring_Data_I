const TEST_CONST__MAX: number = 10000;
export {
    TEST_CONST__MAX
};