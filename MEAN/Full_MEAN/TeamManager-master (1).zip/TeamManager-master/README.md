# TeamManager
Team Manager - Web Application • MEAN-Stack
http://77.220.213.35:2929

![Team Manager](https://image.prntscr.com/image/eZ7Tkw0SRjCd9R4KU7XwiA.png)
