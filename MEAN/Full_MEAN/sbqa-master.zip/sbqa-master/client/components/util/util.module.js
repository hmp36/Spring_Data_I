'use strict';

angular.module('paizaqaApp.util', []);
