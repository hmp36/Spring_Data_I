'use strict';

angular.module('paizaqaApp.admin', [
  'paizaqaApp.auth',
  'ui.router'
]);
