(function(angular, undefined) {
'use strict';

angular.module('paizaqaApp.constants', [])

.constant('appConfig', {userRoles:['guest','user','admin']})

;
})(angular);