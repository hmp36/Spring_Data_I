package com.HP.login_reg.services;

import org.springframework.stereotype.Service;

@Service
public class RoleService {
	// Member variables / service initializations go here
		
	public RoleService(){

	}
	
	// Crud methods to act on services go here.
}
