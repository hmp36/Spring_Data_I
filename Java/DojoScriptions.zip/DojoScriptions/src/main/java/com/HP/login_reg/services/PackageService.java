package com.HP.login_reg.services;

import org.springframework.stereotype.Service;

import com.HP.login_reg.repositories.PackageRepository;

@Service
public class PackageService {
	private PackageRepository packageRepository;

	public PackageRepository getPackageRepository() {
		return packageRepository;
	}

	public void setPackageRepository(PackageRepository packageRepository) {
		this.packageRepository = packageRepository;
	}

	public static void select() {
		// TODO Auto-generated method stub
		
	}
		
}