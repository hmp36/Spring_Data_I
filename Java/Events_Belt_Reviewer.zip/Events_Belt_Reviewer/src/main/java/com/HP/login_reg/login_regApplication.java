package com.HP.login_reg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class login_regApplication{
	public static void main(String[] args) {
		SpringApplication.run(login_regApplication.class, args);
	}
}
